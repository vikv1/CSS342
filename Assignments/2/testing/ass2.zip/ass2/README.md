# Vikrant Verma
## CSS 342

- I removed the "*" check because it was running every single check possible
  which includes checks to conform to the LLVM standard which I don't like
- I added a clang tidy check for casing
- I enabled a google readability check
- Everything else is default to what was given